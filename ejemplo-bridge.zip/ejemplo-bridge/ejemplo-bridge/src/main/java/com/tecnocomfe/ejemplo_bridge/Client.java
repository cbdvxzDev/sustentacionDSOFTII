package com.tecnocomfe.ejemplo_bridge;
import com.tecnocomfe.ejemplo_bridge.device.Device;
import com.tecnocomfe.ejemplo_bridge.device.Radio;
import com.tecnocomfe.ejemplo_bridge.device.TV;
import com.tecnocomfe.ejemplo_bridge.remote.AdvencedRemote;
import com.tecnocomfe.ejemplo_bridge.remote.RemoteC;

public class Client {

    public static void main(String[] args) {
        Device tv = new TV();
        RemoteC remote = new RemoteC(tv);

        System.out.println("Remote controlling TV:");
        remote.togglePower();
        remote.volumeUp();
        remote.channelUp();

        System.out.println();
        Device radio = new Radio();
        AdvencedRemote advancedRemote = new AdvencedRemote(radio);

        System.out.println("Advanced Remote Controlling Radio:");
        advancedRemote.togglePower();
        advancedRemote.mute();
    }
}
