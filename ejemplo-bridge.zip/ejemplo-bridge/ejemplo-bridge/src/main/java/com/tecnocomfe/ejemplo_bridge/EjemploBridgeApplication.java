package com.tecnocomfe.ejemplo_bridge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploBridgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploBridgeApplication.class, args);
	}

}
