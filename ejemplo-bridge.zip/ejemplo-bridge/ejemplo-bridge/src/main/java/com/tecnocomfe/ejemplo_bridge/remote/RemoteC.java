package com.tecnocomfe.ejemplo_bridge.remote;

import com.tecnocomfe.ejemplo_bridge.device.Device;

public class RemoteC {
    protected Device device;

    public RemoteC(Device device) {
        this.device = device;
    }

    public void togglePower() {
        if (device.isEnabled()) {
            device.disable();
        } else {
            device.enable();
        }
    }

    public void volumeDown() {
        int volume = device.getVolume() - 10;
        device.setVolume(volume);
    }

    public void volumeUp() {
        int volume = device.getVolume() + 10;
        device.setVolume(volume);
    }

    public void channelDown() {
        int channel = device.getChannel() - 1;
        device.setChannel(channel);
    }

    public void channelUp() {
        int channel = device.getChannel() + 1;
        device.setChannel(channel);
    }

    public static class AdvancedRemote extends RemoteC {
        public AdvancedRemote(Device device) {
            super(device);
        }

        public void mute() {
            device.setVolume(0);
            System.out.println("Device muted");
        }
    }
}
