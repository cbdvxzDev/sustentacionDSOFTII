package com.tecnocomfe.ejemplo_bridge.device;

public class Radio implements Device {
    private boolean enabled = false;
    private int volume = 30;
    private int channel = 88;

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void enable() {
        enabled = true;
        System.out.println("Radio enabled");
    }

    @Override
    public void disable() {
        enabled = false;
        System.out.println("Radio disabled");
    }

    @Override
    public int getVolume() {
        return volume;
    }

    @Override
    public void setVolume(int percent) {
        this.volume = percent;
        System.out.println("Radio volume set to " + percent);
    }

    @Override
    public int getChannel() {
        return channel;
    }

    @Override
    public void setChannel(int channel) {
        this.channel = channel;
        System.out.println("Radio channel set to " + channel);
    }
}
