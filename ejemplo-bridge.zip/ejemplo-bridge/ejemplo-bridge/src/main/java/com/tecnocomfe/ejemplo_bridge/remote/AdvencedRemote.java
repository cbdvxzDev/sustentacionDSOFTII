package com.tecnocomfe.ejemplo_bridge.remote;

import com.tecnocomfe.ejemplo_bridge.device.Device;

public class AdvencedRemote  extends  RemoteC{

    public AdvencedRemote(Device device){
        super(device);
    }

    public void mute(){
        device.setVolume(0);
        System.out.println("Deviced muted");
    }
}
