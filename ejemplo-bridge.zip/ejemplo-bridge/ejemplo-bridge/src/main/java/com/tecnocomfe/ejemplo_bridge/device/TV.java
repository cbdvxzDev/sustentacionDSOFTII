package com.tecnocomfe.ejemplo_bridge.device;

public class TV implements  Device{
    private boolean enabled = false;
    private int volume = 50;
    private int channel = 1;

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void enable() {
        enabled = true;
        System.out.println("TV enabled");
    }

    @Override
    public void disable() {
        enabled = false;
        System.out.println("TV disabled");
    }

    @Override
    public int getVolume() {
        return volume;
    }

    @Override
    public void setVolume(int percent) {
        this.volume = percent;
        System.out.println("TV volume set to " + percent);
    }

    @Override
    public int getChannel() {
        return channel;
    }

    @Override
    public void setChannel(int channel) {
        this.channel = channel;
        System.out.println("TV channel set to " + channel);
    }

}
