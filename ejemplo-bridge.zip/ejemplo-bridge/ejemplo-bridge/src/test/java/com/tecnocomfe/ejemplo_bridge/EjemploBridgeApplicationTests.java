package com.tecnocomfe.ejemplo_bridge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploBridgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
